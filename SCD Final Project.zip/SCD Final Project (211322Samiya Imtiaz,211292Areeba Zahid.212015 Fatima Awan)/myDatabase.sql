/*#create database myDatabase;
use myDatabase;
#Query to create users table
CREATE TABLE users (
   id INT AUTO_INCREMENT PRIMARY KEY,
   username VARCHAR(50) NOT NULL,
   surname VARCHAR(50) NOT NULL,
   email VARCHAR(50) NOT NULL,
   password VARCHAR(50) NOT NULL,
   is_admin BOOLEAN NOT NULL DEFAULT false
   );

#Query to create tax_records table
CREATE TABLE tax_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    gross_income DOUBLE NOT NULL,
    tax_credits DOUBLE NOT NULL,
    total_tax DOUBLE NOT NULL
);*/




