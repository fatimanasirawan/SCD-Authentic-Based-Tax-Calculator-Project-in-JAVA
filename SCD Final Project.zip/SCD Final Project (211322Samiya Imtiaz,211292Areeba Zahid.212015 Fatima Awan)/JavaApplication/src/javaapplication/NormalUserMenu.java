/*
 * This class represents the menu for a normal user with specific options like modifying profile and tax calculations.
 */
package javaapplication;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * The NormalUserMenu class provides a menu interface for a normal user.
 * Options include modifying their profile, performing tax calculation operations, and exiting the menu.
 * The menu is displayed in a loop until the user chooses to exit.
 */
public class NormalUserMenu extends JFrame {

      private String email;

    public NormalUserMenu(String email) {
        this.email = email;

        setTitle("Normal User Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(4, 1));
        addComponents(panel);

        JButton modifyProfileButton = new JButton("Modify Your Own Profile");
        modifyProfileButton.addActionListener((ActionEvent e) -> {
            new UserProfileModifier();
        });

        JButton taxCalculationButton = new JButton("Tax Calculation Operations");
        taxCalculationButton.addActionListener((ActionEvent e) -> {
            new TaxCalculator();
        });

        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener((ActionEvent e) -> {
            dispose(); // Close the GUI
            System.out.println("Exiting the menu...");
        });

        panel.add(modifyProfileButton);
        panel.add(taxCalculationButton);
        panel.add(exitButton);

        add(panel);
        setVisible(true);
    }

    private void addComponents(JPanel panel) {
        JLabel welcomeLabel = new JLabel("Welcome " + email);
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        panel.add(welcomeLabel);
    }
}


