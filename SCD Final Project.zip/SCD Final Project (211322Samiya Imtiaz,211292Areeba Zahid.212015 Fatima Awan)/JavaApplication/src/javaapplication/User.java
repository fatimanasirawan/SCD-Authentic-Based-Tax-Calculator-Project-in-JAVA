/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author dev
 */
public class User extends JFrame {
    private JTextField userIDField;
    private JTable userTable;
    private DefaultTableModel tableModel;
   
    
    public static void createUsersTable() {
        String url = "jdbc:mysql://localhost:3306/myDatabase";
        String username = "root";
        String password = "samiya22";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement()) {

            String createTableSQL = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "username VARCHAR(50) NOT NULL," +
                    "surname VARCHAR(50) NOT NULL," +
                    "email VARCHAR(50) NOT NULL UNIQUE," +  // Ensure email is unique
                    "password VARCHAR(50) NOT NULL," +
                    "is_admin BOOLEAN NOT NULL DEFAULT false)";

            statement.executeUpdate(createTableSQL);
            System.out.println("Users table created successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    // Method to create a single user record
    public static boolean createUser(String username, String surname, String email, String password, boolean isAdmin) {
        String url = "jdbc:mysql://localhost:3306/myDatabase";
        String dbUsername = "root";
        String dbPassword = "samiya22";

        try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            // SQL statement to insert a user into the users table
            String insertSQL = "INSERT INTO users (username, surname, email, password, is_admin) VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
                preparedStatement.setString(1, username);
                preparedStatement.setString(2, surname);
                preparedStatement.setString(3, email);
                preparedStatement.setString(4, password);
                preparedStatement.setBoolean(5, isAdmin);
                int rowsAffected = preparedStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("User record created successfully.");
                    return true; // Return true if user creation was successful
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Return false if user creation failed
    }
    
   //constructor to display all users in a frame
    public User() {
        setTitle("Display All Users");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);

        // Create a table model with column names
        tableModel = new DefaultTableModel();
        tableModel.addColumn("ID");
        tableModel.addColumn("Username");
        tableModel.addColumn("Surname");
        tableModel.addColumn("Email");
        tableModel.addColumn("isAdmin");

        // Create JTable with the table model
        userTable = new JTable(tableModel);

        // Add JTable to JScrollPane for better visibility
        JScrollPane scrollPane = new JScrollPane(userTable);

        // Add the scroll pane to the frame
        add(scrollPane);

        // Populate the table with data
        displayAllUsers();

        setVisible(true);
    }
    // Method to display all users record
    private void displayAllUsers() {
        String url = "jdbc:mysql://localhost:3306/myDatabase";
        String dbUsername = "root";
        String dbPassword = "samiya22";

        try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            String selectSQL = "SELECT * FROM users";

            try (PreparedStatement preparedStatement = connection.prepareStatement(selectSQL)) {
                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String username = resultSet.getString("username");
                    String surname = resultSet.getString("surname");
                    String email = resultSet.getString("email");
                    boolean isAdmin = resultSet.getBoolean("is_admin");

                    // Add each row to the table model
                    tableModel.addRow(new Object[]{id, username, surname, email, isAdmin});
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    
    }
    
    
}
