/*
 * This class represents the menu for an admin user with options to manage users and modify own profile.
 */
package javaapplication;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * The AdminUserMenu class provides a menu interface for an admin user.
 * Options include listing all users, removing a user, modifying own profile, and exiting the system.
 * The menu is displayed in a loop until the user chooses to exit.
 */
public class AdminUserMenu {

    
    private JFrame frame;
    private String email;
    
    
    public AdminUserMenu(String email) {
        this.email = email;

        frame = new JFrame("Admin User Menu");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        JLabel welcomeLabel = new JLabel("Welcome " + email);
        welcomeLabel.setHorizontalAlignment(JLabel.CENTER);
        frame.add(welcomeLabel, BorderLayout.NORTH);

        JPanel menuPanel = createMenuPanel();
        frame.add(menuPanel, BorderLayout.CENTER);

        frame.setVisible(true);
    }

    private JPanel createMenuPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 1));

        JButton listUsersButton = new JButton("List all users");
        JButton removeUserButton = new JButton("Remove a user");
        JButton modifyProfileButton = new JButton("Modify Your Own Profile");
        JButton exitButton = new JButton("Exit");

        listUsersButton.addActionListener((ActionEvent e) -> {
            JOptionPane.showMessageDialog(frame, "List of all users selected.");
            new User();
        });

        removeUserButton.addActionListener((ActionEvent e) -> {
            JOptionPane.showMessageDialog(frame, "Remove other users from the system selected.");
            new UserDestroy();
        });

        modifyProfileButton.addActionListener((ActionEvent e) -> {
            JOptionPane.showMessageDialog(frame, "Modify Your Own Profile selected.");
           new UserProfileModifier();
        });

        exitButton.addActionListener((ActionEvent e) -> {
            frame.dispose(); // Close the GUI
            System.out.println("Exiting the system...");
        });

        panel.add(listUsersButton);
        panel.add(removeUserButton);
        panel.add(modifyProfileButton);
        panel.add(exitButton);

        return panel;
    }
}







   
    

   