/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */




package javaapplication;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class UserLogin {
    private  JTextField emailField;
    private  JPasswordField passwordField;
    
    public UserLogin(){
        JFrame frame = new JFrame("User Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new GridLayout(5, 2));


        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField();

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();

        JButton loginButton = new JButton("Login");
        
        loginButton.addActionListener((ActionEvent e) -> {
         loginUser();
        });

        frame.add(emailLabel);
        frame.add(emailField);
        frame.add(passwordLabel);
        frame.add(passwordField);
        frame.add(new JLabel());
        frame.add(loginButton);

        frame.setVisible(true);
    }
    
    
    public void loginUser() {
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        
        
        
        boolean loggedIn = isCorrect(email,password);
        if (loggedIn) {
            boolean isAdmin =  CurrentUserManager.isCurrentUserAdmin();
             JOptionPane.showMessageDialog(null, "User login successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            if(isAdmin){
                AdminUserMenu adminUserMenu = new AdminUserMenu(email);
            }else{
                new NormalUserMenu(email);
            }  
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Invalid email or password.", "Error", JOptionPane.ERROR_MESSAGE);
        }
       
    }
    
    
    
    // Function to check if email and password is correct in the database
    public static boolean isCorrect(String email , String password){
         String url = "jdbc:mysql://localhost:3306/myDatabase";
        String dbUsername = "root";
        String dbPassword = "samiya22";

        try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            String selectSQL = "SELECT * FROM users WHERE email = ? AND password = ?";

            try (PreparedStatement preparedStatement = connection.prepareStatement(selectSQL)) {
                preparedStatement.setString(1, email);
                preparedStatement.setString(2, password);
                ResultSet resultSet = preparedStatement.executeQuery();
                CurrentUserManager.setCurrentUserEmail(email);
                return resultSet.next(); // Returns true if login is successful, false otherwise
            }
        } catch (SQLException e) {
        }
        return false; // Return false if an exception occurs
    }
    
}
