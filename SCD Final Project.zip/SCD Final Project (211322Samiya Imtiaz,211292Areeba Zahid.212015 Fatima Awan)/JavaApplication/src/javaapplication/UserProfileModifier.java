/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 *
 * @author dev
 */

public class UserProfileModifier extends JFrame{

     private JTextField usernameField;
    private JTextField surnameField;
    private JLabel resultLabel;

    public UserProfileModifier() {
        setTitle("User Profile Modifier");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(4, 2));
        addComponents(panel);

        JButton updateUsernameButton = new JButton("Update Username");
        updateUsernameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateUsername();
            }
        });

        JButton updateSurnameButton = new JButton("Update Surname");
        updateSurnameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateSurname();
            }
        });

        add(panel, BorderLayout.CENTER);
        add(updateUsernameButton, BorderLayout.SOUTH);
        add(updateSurnameButton, BorderLayout.SOUTH);

        resultLabel = new JLabel();
        add(resultLabel, BorderLayout.NORTH);

        setVisible(true);
    }

    private void addComponents(JPanel panel) {
        JLabel usernameLabel = new JLabel("New Username:");
        usernameField = new JTextField();

        JLabel surnameLabel = new JLabel("New Surname:");
        surnameField = new JTextField();

        panel.add(usernameLabel);
        panel.add(usernameField);
        panel.add(surnameLabel);
        panel.add(surnameField);
    }

    private void updateUsername() {
        String newUsername = usernameField.getText().trim();

        if (!newUsername.isEmpty()) {
            if (updateDatabaseUsername(newUsername)) {
                resultLabel.setText("Username updated successfully.");
            } else {
                resultLabel.setText("Failed to update username.");
            }
        } else {
            resultLabel.setText("Please enter a new username.");
        }
    }

    private void updateSurname() {
        String newSurname = surnameField.getText().trim();

        if (!newSurname.isEmpty()) {
            if (updateDatabaseSurname(newSurname)) {
                resultLabel.setText("Surname updated successfully.");
            } else {
                resultLabel.setText("Failed to update surname.");
            }
        } else {
            resultLabel.setText("Please enter a new surname.");
        }
    }

    private boolean updateDatabaseUsername(String newUsername) {
        String url = "jdbc:mysql://localhost:3306/myDatabase";
        String dbUsername = "root";
        String dbPassword = "samiya22";

        try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            String updateSQL = "UPDATE users SET username = ? WHERE email = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {
                preparedStatement.setString(1, newUsername);
                preparedStatement.setString(2, getCurrentUserEmail());
                int rowsAffected = preparedStatement.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private boolean updateDatabaseSurname(String newSurname) {
        String url = "jdbc:mysql://localhost:3306/myDatabase";
        String dbUsername = "root";
        String dbPassword = "samiya22";

        try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            String updateSQL = "UPDATE users SET surname = ? WHERE email = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {
                preparedStatement.setString(1, newSurname);
                preparedStatement.setString(2, getCurrentUserEmail());
                int rowsAffected = preparedStatement.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private String getCurrentUserEmail() {
        return CurrentUserManager.getCurrentUserEmail();
    }
}
