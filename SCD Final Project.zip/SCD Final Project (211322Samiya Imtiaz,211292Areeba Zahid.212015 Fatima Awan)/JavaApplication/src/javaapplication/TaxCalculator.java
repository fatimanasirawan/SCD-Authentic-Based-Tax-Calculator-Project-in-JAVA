/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication;


import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author dev
 */
public class TaxCalculator extends JFrame{

    private JTextField nameField;
    private JTextField grossIncomeField;
    private JTextField taxCreditsField;
    private JTextArea resultArea;

    public TaxCalculator() {
        setTitle("Tax Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(5, 2));
        addComponents(panel);

        JButton calculateButton = new JButton("Calculate Tax");
        calculateButton.addActionListener((ActionEvent e) -> {
            calculateTax();
        });

        add(panel, BorderLayout.CENTER);
        add(calculateButton, BorderLayout.SOUTH);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        add(scrollPane, BorderLayout.NORTH);

        setVisible(true);
    }

    private void addComponents(JPanel panel) {
        JLabel nameLabel = new JLabel("Name:");
        nameField = new JTextField();

        JLabel grossIncomeLabel = new JLabel("Gross Income:");
        grossIncomeField = new JTextField();

        JLabel taxCreditsLabel = new JLabel("Tax Credits:");
        taxCreditsField = new JTextField();

        panel.add(nameLabel);
        panel.add(nameField);
        panel.add(grossIncomeLabel);
        panel.add(grossIncomeField);
        panel.add(taxCreditsLabel);
        panel.add(taxCreditsField);
    }

    private void calculateTax() {
        try {
            String name = nameField.getText().trim();
            double grossIncome = Double.parseDouble(grossIncomeField.getText());
            double taxCredits = Double.parseDouble(taxCreditsField.getText());

            // Calculate taxes
            double incomeTax = calculateIncomeTax(grossIncome);
            double usc = calculateUSC(grossIncome);
            double prsi = calculatePRSI(grossIncome);

            double totalTax = incomeTax + usc + prsi;

            // Display results in the JTextArea
            resultArea.setText("Name: " + name + "\n");
            resultArea.append("Income Tax: " + incomeTax + "\n");
            resultArea.append("USC: " + usc + "\n");
            resultArea.append("PRSI: " + prsi + "\n");
            resultArea.append("Total Tax: " + totalTax + "\n");

            // Store information in the database
            saveToDatabase(name, grossIncome, taxCredits, totalTax);

        } catch (NumberFormatException | SQLException ex) {
            resultArea.setText("Invalid input. Please enter valid numeric values.");
        }
    }

    private double calculateIncomeTax(double grossIncome) {
        // For simplicity, let's assume a fixed rate for income tax
        return 0.3 * grossIncome;
    }

    private double calculateUSC(double grossIncome) {
        // For simplicity, let's assume a fixed rate for USC
        return 0.05 * grossIncome;
    }

    private double calculatePRSI(double grossIncome) {
        // For simplicity, let's assume a fixed rate for PRSI
        return 0.02 * grossIncome;
    }

    private void saveToDatabase(String name, double grossIncome, double taxCredits, double totalTax) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/myDatabase";
        String username = "root";
        String password = "samiya22";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            // SQL query to insert data into the database
            String sql = "INSERT INTO tax_records (name, gross_income, tax_credits, total_tax) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, name);
                preparedStatement.setDouble(2, grossIncome);
                preparedStatement.setDouble(3, taxCredits);
                preparedStatement.setDouble(4, totalTax);

                // Execute the query
                preparedStatement.executeUpdate();
            }
        }
    }
}
