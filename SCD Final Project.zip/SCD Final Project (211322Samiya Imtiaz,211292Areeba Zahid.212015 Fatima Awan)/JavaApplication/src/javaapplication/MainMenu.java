/*
 * This class represents the main menu of the application,
 * providing options for user registration, login, and exiting the application.
 */
package javaapplication;

import javax.swing.*;
import java.awt.event.ActionEvent;


/**
 * The MainMenu class presents the main menu of the application.
 * It offers options for user registration, login, and exiting the application.
 * Users can navigate through these options using user input.
 */
public class MainMenu {
    private final JFrame frame;
    private final JPanel panel;
    private JButton registerButton;
    private JButton loginButton;
    private JButton exitButton;
    
    
    public MainMenu(){
        frame = new JFrame("Tax Calculation");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);

        frame.setVisible(true);
    }
    
    
    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel titleLabel = new JLabel("Welcome to our Application");
        titleLabel.setBounds(10, 20, 300, 25);
        panel.add(titleLabel);

        registerButton = new JButton("Register");
        registerButton.setBounds(10, 60, 80, 25);
        panel.add(registerButton);

        loginButton = new JButton("Login");
        loginButton.setBounds(100, 60, 80, 25);
        panel.add(loginButton);

        exitButton = new JButton("Exit");
        exitButton.setBounds(190, 60, 80, 25);
        panel.add(exitButton);

        registerButton.addActionListener((ActionEvent e) -> {
            registerUser();
        });

        loginButton.addActionListener((ActionEvent e) -> {
            loginUser();
        });

        exitButton.addActionListener((ActionEvent e) -> {
            frame.dispose(); // Close the GUI
        });
    }

 
    
    /**
     * Handles the registration process for a new user.
     */
    private static void registerUser() {
        //frame.dispose(); // Close the main menu GUI
        new UserRegister();
    }

    /**
     * Handles the login process for an existing user.
     */
    private static void loginUser() {
        new UserLogin();
        
    }
}







