/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author dev
 */
public class UserDestroy extends JFrame {
   private JTextField userIDField;
   private JLabel resultLabel;

    public UserDestroy() {
        setTitle("Delete User");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 150);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2));
        addComponents(panel);

        JButton deleteButton = new JButton("Delete User");
        deleteButton.addActionListener((ActionEvent e) -> {
            deleteUser();
        });

        add(panel, BorderLayout.CENTER);
        add(deleteButton, BorderLayout.SOUTH);

        resultLabel = new JLabel();
        add(resultLabel, BorderLayout.NORTH);

        setVisible(true);
    }

    private void addComponents(JPanel panel) {
        JLabel userIDLabel = new JLabel("User ID:");
        userIDField = new JTextField();

        panel.add(userIDLabel);
        panel.add(userIDField);
    }

    private void deleteUser() {
        try {
            int userID = Integer.parseInt(userIDField.getText());

            String url = "jdbc:mysql://localhost:3306/myDatabase";
            String dbUsername = "root";
            String dbPassword = "samiya22";

            try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword)) {
                if (isUserExists(connection, userID)) {
                    deleteUser(connection, userID);
                    resultLabel.setText("User with ID " + userID + " has been deleted.");
                } else {
                    resultLabel.setText("User with ID " + userID + " does not exist in the database.");
                }
            }
        } catch (NumberFormatException | SQLException e) {
            resultLabel.setText("Invalid input. Please enter a valid user ID.");
        }
    }
    
    // Function to check if user exists by ID
   private static boolean isUserExists(Connection connection, int userID) throws SQLException {
        String selectSQL = "SELECT COUNT(*) AS count FROM users WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(selectSQL)) {
            preparedStatement.setInt(1, userID);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt("count");
                return count > 0;
            }
        }
        return false;
    }
    
     // Function to delete user by ID
    private static void deleteUser(Connection connection, int userID) throws SQLException {
        String deleteSQL = "DELETE FROM users WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {
            preparedStatement.setInt(1, userID);
            preparedStatement.executeUpdate();
        }
    }
    
    
}
