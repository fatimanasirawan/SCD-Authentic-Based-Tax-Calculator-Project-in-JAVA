/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package javaapplication;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

/**
 *
 * @author dev
 */
public class UserRegister {
    private final JTextField usernameField;
    private final JTextField surnameField;
    private final JTextField emailField;
    private final JPasswordField passwordField;
    
    
    
    public UserRegister() {
        JFrame frame = new JFrame("User Registration");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new GridLayout(5, 2));

        JLabel usernameLabel = new JLabel("Username:");
        usernameField = new JTextField();

        JLabel surnameLabel = new JLabel("Surname:");
        surnameField = new JTextField();

        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField();

        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener((ActionEvent e) -> {
            RegisterUser();
        });

        frame.add(usernameLabel);
        frame.add(usernameField);
        frame.add(surnameLabel);
        frame.add(surnameField);
        frame.add(emailLabel);
        frame.add(emailField);
        frame.add(passwordLabel);
        frame.add(passwordField);
        frame.add(new JLabel());
        frame.add(registerButton);

        frame.setVisible(true);
    }
    
    
   private void RegisterUser() {
        String username = usernameField.getText().trim();
        String surname = surnameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || surname.isEmpty() || email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All fields must be filled out", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean isUnique = isEmailUnique(email);

        if (!isUnique) {
            JOptionPane.showMessageDialog(null, "Email is already taken. Please enter a different email.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        boolean isSuccess = User.createUser(username, surname, email, password, false);

        if (isSuccess) {
            JOptionPane.showMessageDialog(null, "User registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
           new NormalUserMenu(email);
            // You might want to close the GUI or reset the fields here
        } else {
            JOptionPane.showMessageDialog(null, "Error occurred while registering user", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

   
    // Function to check if email is unique in the database
    public static boolean isEmailUnique(String email) {
        String url = "jdbc:mysql://localhost:3306/myDatabase";
        String dbUsername = "root";
        String dbPassword = "samiya22";

        try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword)) {
            String selectSQL = "SELECT COUNT(*) AS count FROM users WHERE email = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(selectSQL)) {
                preparedStatement.setString(1, email);
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    int count = resultSet.getInt("count");
                    return count == 0;
                }
            }
        } catch (SQLException e) {
        }
        return false;
    }

}






